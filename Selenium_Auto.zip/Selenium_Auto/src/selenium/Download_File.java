package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;


public class Download_File {

	/*Set the browser.dowload.folderlist property to 2 (If by default it is showing as 1).
	 * open mozilla firefox > enter "about:config on url field" > tap on the enter button >
	 * Click on the button "I'll be careful, I promise" to get inside the properties
	 * enter browser.download.folderlist on the search panel
	 * double click and change the value from '1' to '2'
	 */
	
		public static void main(String[] args) {
		    FirefoxProfile profile = new FirefoxProfile(); 

		    profile.setPreference("browser.download.folderList", 2);     
		    profile.setPreference("browser.download.dir","C:\\Users\\MUSBAH15\\Desktop\\nice folder"); 
		    //folder will be automatically created based on the mentioned path
		    profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/msword,application/x-rar-compressed,application/octet-stream,application/csv,text/csv");
		    /*It never ask the popup mentioning "Save to disk" location
		     * And also we have to mention the type of files which it should allow, 
		     * otherwise it will block those files*/
		    WebDriver driver = new FirefoxDriver(profile);
		    driver.get("http://filehippo.com/download_skype/"); //provide the file link
		    driver.findElement(By.xpath("//*[@id='program-header']/div[4]/a[1]")).click(); //Download button xpath
		    driver.findElement(By.xpath("//*[@id='download-link']/span")).click();
		   // driver.findElement(By.xpath("html/body/a[3]")).click();

		    
		   
		}
		

	}
