package selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Dar_Automation {

	/**
	 * @throws Exception 
	 * @param args
	 * @throws 
	 */
	public static void main(String[] args) throws Exception  {
		WebDriver driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://musbah.com/dar/index.php/login");
	System.out.println("1."+driver.getTitle());
	System.out.println("2.Login Page Validation"+"\n"+"\n"+"a. without credentials click on login button");
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	driver.findElement(By.xpath("//*[@id='wrapper']/div[3]/form/div[2]/input")).click();
	Thread.sleep(1000);
	System.out.println("Error message shown: "+driver.findElement(By.xpath("//*[@id='wrapper']/div[3]/form/div[1]")).getText());
	System.out.println("\n"+"*****************************************************"+"\n");
	System.out.println("b. with Invalid credentials");
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	driver.findElement(By.xpath("//*[@id='wrapper']/div[3]/form/input[1]")).sendKeys("kp@bug.com");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id='wrapper']/div[3]/form/input[2]")).sendKeys("123123");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id='wrapper']/div[3]/form/div[2]/input")).click();
	Thread.sleep(1000);
	//String message= driver.findElement(By.xpath("//*[@id='wrapper']/div[3]/form/div[1]")).getText();
	System.out.println("Error Message shown: "+driver.findElement(By.xpath("//*[@id='wrapper']/div[3]/form/div[1]")).getText());
	Thread.sleep(1000);
	System.out.println("\n"+"****************************************************"+"\n");
	System.out.println("c. with valid credentials");
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id='wrapper']/div[3]/form/input[2]")).sendKeys("kp123");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id='wrapper']/div[3]/form/div[2]/input")).click();
	Thread.sleep(1000);
	System.out.println("3."+"New Url is: "+driver.getCurrentUrl());
	String url="http://musbah.com/dar/index.php/login/check_login";
	String url1="http://musbah.com/dar/index.php/teacher/teacher";
	if(driver.getCurrentUrl().equalsIgnoreCase(url)) // for string type comparison you have to use .equalsto() or .equalsIgnoreCase(), "==" is used for integer type
	{
	System.out.println("Error message shown: "+driver.findElement(By.xpath("//*[@id='wrapper']/div[3]/form/div[1]")).getText());
	}
	else if(driver.getCurrentUrl().equalsIgnoreCase(url1))
	{
	driver.findElement(By.xpath("//*[@id='logout_btn']")).click(); 
	Thread.sleep(1000);
	System.out.println("User clicked on logout button");
	driver.findElement(By.xpath("//*[@id='st-logout-conform']/div/div[2]/a[1]")).click();
	Thread.sleep(1000);
	System.out.println("User clicked on 'No' button on the warning Popup");
	driver.findElement(By.xpath("//*[@id='logout_btn']")).click();
	Thread.sleep(1000);
	System.out.println("User again clicked on logout button");
	System.out.println("User clicked on 'Yes' button on the warning Popup");
	driver.findElement(By.xpath("//*[@id='st-logout-conform']/div/div[2]/a[2]")).click();
	Thread.sleep(1000);
	System.out.println("4."+"User Logged Out"+"\n"+"New url is:"+driver.getCurrentUrl());
	}
	System.out.println("execution completed");
	
	
	BackandFront bandf=new BackandFront();//the name of file which need to be executed next after executing this file"i.e, BackandFront.java"
	try {
		bandf.main(null);
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	/* Process processRun = null;
     try {
         processRun = Runtime.getRuntime().exec("java Automation");
     } catch (IOException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
     }*/
     
     
	}
	
	
	
}
