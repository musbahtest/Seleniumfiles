package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;


public class Module1 {

	
	public static void main(String[] args) {
		
WebDriver ref=new FirefoxDriver();
//System.setProperty("webdriver.chrome.driver", "C:\\Users\\System-2\\Desktop\\chromedriver.exe");
//WebDriver ref=new ChromeDriver();	
//System.setProperty("webdriver.ie.driver", "C:\\Users\\System-2\\Desktop\\IEDriverServer.exe");
//WebDriver ref=new HtmlUnitDriver();
ref.get("https://www.gmail.com");
ref.findElement(By.xpath("//*[@id='Email']")).sendKeys("chandan");
//System.out.println(ref.getTitle());

	}

}


