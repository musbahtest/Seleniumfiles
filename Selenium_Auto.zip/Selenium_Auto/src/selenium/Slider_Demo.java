package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

// scroll the scroll bars of the webpage from one position to another in a browser 
public class Slider_Demo {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		//FirefoxProfile profile = new FirefoxProfile();
		//profile.setEnableNativeEvents(true);
		WebDriver driver = new FirefoxDriver();	
		driver.get("http://www.americangolf.co.uk/clothing-shoes/shirts?pmax=100&pmin=5");
		
		WebElement slider = driver.findElement(By.xpath("//*[@id='secondary']/div[1]/div[2]/div[1]/div[1]/span[2]"));
		// slides will have the tagname 'span'
		Actions act = new Actions(driver); 
		/*this Action keyword is essential for 
		 * mouse movement related activities*/
		act.dragAndDropBy(slider, -100, 0).build().perform();
		
		/*To scroll down web page by 900 pixels In x(vertical) direction.
		 * You can y parameter to scroll page In horizontal direction.  
		 * */
		JavascriptExecutor javascript = (JavascriptExecutor) driver;  
		javascript.executeScript("window.scrollBy(0,900)", ""); 
		Thread.sleep(5000);
		//To scroll up web page by 300 pixels In x(vertical) direction.  
		javascript.executeScript("window.scrollBy(0,-300)", "");  

		/*//Scroll down to bottom of the page.  
		  JavascriptExecutor javascript = (JavascriptExecutor) driver;  
		  javascript.executeScript("window.scrollTo(0, document.body.scrollHeight)", ""); */
		

/*	//Scroll upto one particular element in that webpage
     act.sendKeys(Keys.PAGE_DOWN);  
     Thread.sleep(5000);  
     act.click(driver.findElement(By.partialLinkText("Nike Golf Momentum Stripe Slim"))).perform();*/
	}

}
