package selenium;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;

/*Enter this text "firefox.exe -p profilemanager" in the window search panel 
 *(click start/windows > Enter the text > create a new profile and save */

public class Profile_Example {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ProfilesIni ini=new ProfilesIni(); // intializing a new profile
		FirefoxProfile pf=ini.getProfile("karthik"); // taking the new profile with name karthik
		FirefoxDriver driver=new FirefoxDriver();
		pf.setAcceptUntrustedCertificates(true); 
		// this will neglect the certification popups (it won't show those kind of legal popups)
		driver.get("https://google.com"); 
		//driver.close(); // close the firefox window
		//driver.quit(); // close all ff windows associated with driver
	}

}
