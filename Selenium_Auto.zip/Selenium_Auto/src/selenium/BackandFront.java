package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class BackandFront {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		WebDriver driver=new FirefoxDriver();
		driver.get("https://www.gmail.com");
		driver.findElement(By.linkText("Create account")).click();
		// find the linktext written as "Create account" and click on it 
		driver.navigate().back(); //navigate to back
		driver.navigate().forward(); //navigate to next

	}

}
