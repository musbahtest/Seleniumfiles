package selenium;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;




public class Locators_Example {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		WebDriver driver=null;
		driver=new FirefoxDriver();
		driver.get("http://www.gmail.com");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//driver.findElement(By.cssselector("input[id='Email']")).sendKeys("karthi");
		//driver.findElement(By.cssSelector("#Email")).sendKeys("karthik");
		//driver.findElement(By.cssSelector("input[name^='Em']")).sendKeys("kjkjk");
		//driver.findElement(By.cssSelector("input[name$='il']")).sendKeys("kjkjk");
		//driver.findElement(By.cssSelector("css=input:contains('Email')")).click();
		driver.findElement(By.cssSelector("input[id='next']")).click();
	}
}
