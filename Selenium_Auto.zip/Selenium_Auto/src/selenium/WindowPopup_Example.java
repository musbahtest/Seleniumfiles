package selenium;

import java.util.Set;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class WindowPopup_Example {

	/**
	 * @throws Exception 
	 * @param args
	 * @throws  
	 */
	public static void main(String[] args) throws Exception  {
		WebDriver driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS );
		driver.get("http://www.htmlcodetutorial.com/linking/linking_famsupp_131.html");
		driver.findElement(By.xpath(".//*[@id='node-513']/div/div[1]/div/div/p[3]/a")).click(); 
		// on clicking this link will launch another window
		//driver.findElement(By.linkText("back to Popup Windows: dependent")).click(); 
		/* if we execute the above line it won't work because the given link text is in another browser window. 
		 * if we want to click a linktext named "back to Popup Windows: dependent" on the other browser window, 
		 * 1st we have to switch to that new window from current exisiting browser window */
		Set<String> winid=driver.getWindowHandles();
		System.out.println("total window"+winid.size()); 
		// o/p: it will show the totoal number of windows opened like "total window2" 
		Iterator<String> it= winid.iterator();
		String mainid=it.next(); // mainid will hold the main (1st) browser id 
		System.out.println(mainid); // it will show the window id like "{8420d9de-3806-482e-b6cf-3558040c39f0}" 
		String tabid=it.next(); // here it will hold the 2nd browser window id
		System.out.println(tabid); // it will show the window id like "{b6e4776b-264d-4520-8778-4d855513a878}"
		//System.out.println(mainid+"\t"+tabid); // displaying both once again
		driver.switchTo().window(tabid); // we're switching to new 2nd browser window by giving its window id
		driver.findElement(By.linkText("back to Popup Windows: dependent")).click();
		Thread.sleep(1000);
		//driver.close(); // for closing the 1st browser and keep only the recent window
		//driver.quit(); //wil close both browsers or all
	}

}
