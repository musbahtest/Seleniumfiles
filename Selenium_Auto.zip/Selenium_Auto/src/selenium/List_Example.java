package selenium;

import java.util.ArrayList;
import java.util.List;




public class List_Example {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<String> li=new ArrayList<String>();
		li.add("india");
		li.add("usa");
		li.add("london");
		li.add("india");
		System.out.println(li.size());
		System.out.println(li.get(2));

	}

}
