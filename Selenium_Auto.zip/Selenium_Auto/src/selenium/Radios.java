package selenium;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Radios {

	
	public static void main(String[] args) throws Exception {

		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://www.echoecho.com/htmlforms10.htm");
		//driver.switchTo().frame(0);
		//WebElement tabl=driver.findElement(By.xpath("html/body/div[3]/table[9]/tbody/tr/td[4]/table/tbody/tr/td/div/span/form/table[3]/tbody/tr/td/table/tbody/tr/td"));
		//tabl.findElement(By.xpath("html/body/div[3]/table[9]/tbody/tr/td[4]/table/tbody/tr/td/div/span/form/table[3]/tbody/tr/td/table/tbody/tr/td/input[1]")).click();
		List<WebElement> radios1 = driver.findElements(By.xpath("//input[@name='group1']"));
		System.out.println("Total radio buttons in group1 table -> "+ radios1.size());
		radios1.get(0).click();
		System.out.println("**********************");
		System.out.println(radios1.get(0).getAttribute("checked")); 
		System.out.println(radios1.get(1).getAttribute("checked"));
		System.out.println(radios1.get(2).getAttribute("checked"));
		//this is for milk
		Thread.sleep(2000);
		radios1.get(1).click();
		System.out.println("**********************");
		System.out.println(radios1.get(0).getAttribute("checked")); 
		System.out.println(radios1.get(1).getAttribute("checked"));
		System.out.println(radios1.get(2).getAttribute("checked"));
		//this is for butter
		Thread.sleep(2000);
		radios1.get(2).click();
		System.out.println("**********************");
		System.out.println(radios1.get(0).getAttribute("checked")); 
		System.out.println(radios1.get(1).getAttribute("checked"));
		System.out.println(radios1.get(2).getAttribute("checked"));
		//this is for cheese
		
		
		Thread.sleep(2000);
		List<WebElement> radios2 = driver.findElements(By.xpath("//input[@name='group2']"));
		System.out.println("Total radio buttons in group2 table -> "+ radios2.size());
		radios2.get(0).click();
		System.out.println("**********************");
		System.out.println(radios2.get(0).getAttribute("checked")); 
		System.out.println(radios2.get(1).getAttribute("checked"));
		System.out.println(radios2.get(2).getAttribute("checked"));
		//this is for water
		radios2.get(1).click();
		System.out.println("**********************");
		System.out.println(radios2.get(0).getAttribute("checked")); 
		System.out.println(radios2.get(1).getAttribute("checked"));
		System.out.println(radios2.get(2).getAttribute("checked"));
		//this is for Beer
		radios2.get(2).click();
		System.out.println("**********************");
		System.out.println(radios2.get(0).getAttribute("checked")); 
		System.out.println(radios2.get(1).getAttribute("checked"));
		System.out.println(radios2.get(2).getAttribute("checked"));
		//this is for wine

		
		
	}

}

