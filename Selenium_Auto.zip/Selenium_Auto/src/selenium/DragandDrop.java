package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;


public class DragandDrop {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		WebDriver driver=new FirefoxDriver();
		driver.get("http://jqueryui.com/demos/droppable/");
		driver.manage().window().maximize();
		int size=driver.findElements(By.tagName("iframe")).size(); 
		/*this will find the iframe acvailable in the launched driver and 
		 * .size() will give the total number of iframe count */
		System.out.println(size); // may be out put will show as 1 if only one ifame is available
		Actions act = new Actions(driver); //for mouse movement (drag and drop), we are using Action keyword
		driver.switchTo().frame(0);//only one iframe is there, hence i want to do operation on that frame, so frame(0)
		/* to perform any action in the iframe, 
		 * first switch to that Iframe and 
		 * then perform action inside it*/ 
		WebElement src = driver.findElement(By.xpath("//*[@id='draggable']"));
		//the xpath of the item which is to be selected for drag and drop (source)
		WebElement dest = driver.findElement(By.xpath("//*[@id='droppable']"));
		//the xpath of the place where the selected item to be place (destination)
		act.dragAndDrop(src, dest).clickAndHold().build().perform();
		/*the above command will click and hold the source file 
		 * and will drag it and drop it on the destination 
		 */
		System.out.println(driver.findElement(By.xpath("//*[@id='droppable']/p")).getText());
		/*the above command is to get the text that will display on 
		 * the text field after the source is placed on destination
		 */
		driver.navigate().back();
	}
	}


