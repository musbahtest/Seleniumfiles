package selenium;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

//Iframe concept
public class Frame_Example {

	
	public static void main(String[] args) throws Exception {
		WebDriver driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://www.w3schools.com/tags/tryit.asp?filename=tryhtml_frame_rows");
		//driver.manage().window().maximize();
		int size=driver.findElements(By.tagName("iframe")).size();
		//finding the number of iframes available in that website
		System.out.println(size);
		System.out.println("Bingo");
		//Thread.sleep(2000);
		driver.switchTo().frame(0);
		//switch to 1st frame, i.e frame(0)
     String x=driver.findElement(By.xpath("//p[@text=html/body/h3]")).getText();  
       //store the text available on that iframe into 'x'
	System.out.println(x);//print/display the text saved on 'x'
	}

}
