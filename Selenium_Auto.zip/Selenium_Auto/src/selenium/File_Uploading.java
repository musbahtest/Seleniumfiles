package selenium;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

//File uploading using AutoIT

public class File_Uploading {

	
	public static void main(String[] args) throws IOException {
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://www.websupergoo.com/file-upload-1.htm");
		
		//driver.findElement(By.xpath("//input[@id='photo']")).sendKeys("F:\\ashish.jpg");
		
		// AUTO - IT
		/* configuration:
		 * Install autoIt > go to C drive-Programfiles > open AutoIt folder > Open SciTE folder >
		 * Open Scite.exe > in that window type the following 4 lines:
			$windowHandle = WinGetHandle("File Upload")
	        WinActivate($windowHandle)
	        ControlSetText("File Upload", "", "[CLASS:Edit; INSTANCE:1]", $CmdLine[1])
	        ControlClick("File Upload", "","[CLASS:Button; INSTANCE:2]")
	      */
		 /* finding class and Instance, And to generate .exe file for uploading purpose:
		  * Open Browser with above mentioned url > click on the choose file to upload/browse button
		  * One popup window will appear to select the file to upload (1st popup)
		  * Now click and run "au3info.exe" file from path C:Programfiles\Autoit3\au3info.exe
		  * one Autoit finder window will appear > uncheck freeze mode from option menu list
		  * click on the locator image on the finder tool > drag and place over the edit field, button fields
		  * available on the 1st Popup. Give the class name and instance name on the SciTE command window >
		  * Save and compile > .au3 file and .exe file will be generate on the path given for saving
		  * */
		driver.findElement(By.xpath("//*[@id='content']/form/fieldset/input[1]")).click();
		 Process process = new ProcessBuilder("C:\\Users\\MUSBAH15\\Desktop\\new.exe",
			                "E:\\FanosEdu screenshots 06-08-2014\\book color.png","open").start();
		 /*for execution of the process we need to activate the autoit.exe file which 
		  * was generated based on our script. Give its pathaddress and also the address of the 
		  * file path which has to be uploaded  
		  */
		 System.out.println(System.getProperty("user.dir"));
	}

}


	


