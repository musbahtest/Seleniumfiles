package selenium;

import java.util.List;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;


public class Mouse_Movement {

	
	public static void main(String[] args) throws Exception {
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.americangolf.co.uk/");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Actions act=new Actions(driver);
		WebElement ele=driver.findElement(By.xpath("//*[@id='navigation']/nav/ul/li[2]/a"));
		//Thread.sleep(5000);
		//WebElement ele1=driver.findElement(By.xpath("//*[@id='navigation']/nav/ul/li[2]/div/div[1]/ul/li[3]/a"));
		//WebElement ele2=driver.findElement(By.xpath)
		act.moveToElement(ele).build().perform();
		//Thread.sleep(5000);
		//act.moveToElement(ele1).build().perform();
		WebElement el2=driver.findElement(By.xpath("//*[@id='CLOTHFOOTW_1']"));
		List<WebElement> alllinks=el2.findElements(By.tagName("a"));
		System.out.println("total links"+alllinks.size());
		int total=alllinks.size();
		Random r=new Random();
		alllinks.get(r.nextInt(total)).click();
		
		//driver.findElement(By.xpath("//*[@id='CLOTHFOOTW_2']/div[1]/ul[2]/li/ul/li[2]/ul/li[1]/a")).click();

	}

}
