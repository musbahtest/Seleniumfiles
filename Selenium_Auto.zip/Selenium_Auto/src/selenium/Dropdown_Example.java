package selenium;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class Dropdown_Example {

	
	public static void main(String[] args) throws Exception {
		WebDriver driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://www.designer-daily.com/mega-drop-down-navigation-menus-12796");
		//Thread.sleep(2000);
		//driver.findElement(By.xpath("//*[@id='sidebar']/aside[7]/select")).click();
		WebElement droplist=driver.findElement(By.xpath(".//*[@id='sidebar']/aside[7]/div/select"));
		Thread.sleep(2000);
		droplist.sendKeys("2013");
		/*this will find the dropdown field and type '2013' on that field, 
		 * so that that particular item will be shown in that list
		 */ 
		List<WebElement> allOptions = droplist.findElements(By.tagName("option"));
		/*dropdown tag name will be with "option"
		 * Here all the options in the dropdown box will be stored in 'alloptions'*/
		System.out.println("Total options in list -> "+ allOptions.size());
		//will show the total number of option count 
		for(int i=0;i<allOptions.size();i++)
		{
			System.out.println(allOptions.get(i).getText()+" ---- "+ allOptions.get(i).getAttribute("selected"));
			/*Inorder to list all the option text in that dropdown list*/
		}
		
		Select s=new Select(droplist); //this is to deselect the selected dropdownlist
		s.deselectByIndex(3);
		//s.g

	}

}
