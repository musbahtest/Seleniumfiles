package selenium;

import java.util.Random;
//to print a random number from a set of numbers

public class RandomNum {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
Random r=new Random(); //keyword "Random" is used
int z=r.nextInt(100);
System.out.println(z);
//on every execution it will print any random number from 0 to 100
	}

}
