package selenium;

import java.util.List;
import java.util.concurrent.TimeUnit;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class AllLinks {

	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		/*driver.get("http://www.bbc.com");
		//driver.findElement(By.linkText("Earth")).click();
		//driver.findElement(By.id("blq-search-q")).sendKeys("Asia news");
		//String x=driver.findElement(By.name("q")).getAttribute("placeholder");
		//System.out.println(x);*/
		// here we're going to find the number of links available in a particular place
		driver.get("http://stackoverflow.com/questions/21898567/how-to-click-on-all-links-in-web-page");
		WebElement ele=driver.findElement(By.xpath(".//*[@id='footer']/div"));
		/* above we have assigned one particular region with Xpath id "'footer']/div" to an object named "ele".
		 * Now this ele will hold all the values & ids of all the links available inside the region "".//*[@id='footer']/div"". 
		 * suppose those region have more than 50 links, so here we're going to get its total number and names
		 */
		List<WebElement> all=ele.findElements(By.tagName("a")); 
		/* all links will have the tag name "a", We know "ele" is storing all the datas, names, links etc.. 
		 * from that mentioned region. Now all the links with tagname "a" (Which are available inside the region) 
		 * will be stored in the object "all"*/
		System.out.println(all.size()); //all.size() this will provide total number of links count
		//int tot=all.size();
		String link35 = all.get(34).getText(); //will fetch the 35th link (0 to 34) and .gettext() will fetch the text
		System.out.println(link35); //display the text of that link 
		for(int i=0;i<all.size();i++)
		{
			System.out.println(all.get(i).getText()); 
			// will display all the names of links available inside the region ".//*[@id='footer']/div"
		}		
		//driver.close();
		/*Now i want to click all links available inside theat region one after another, 
		 *so the following steps will help you to do like that*/
		for(int i=0;i<all.size();i++) //will click all the links one by one
		{
			all.get(i).click();
			System.out.println(driver.getTitle()); 
			//it will display the link name which are clicked one by one
			Thread.sleep(2000);
			driver.get("http://stackoverflow.com/questions/21898567/how-to-click-on-all-links-in-web-page"); 
			/*while clicking, next webpage will load > again we have to go to previous page to click another link,
			 * hence we're providing the url*/ 
			Thread.sleep(1000);
			ele=driver.findElement(By.xpath(".//*[@id='footer']/div")); 
			// again we have to go to that particular region for selecting next link
			all=ele.findElements(By.tagName("a"));
			System.out.println("-----------");
		} 
		
		
	}

}
