package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

//Sliding the seek bar positions 

public class Dragging_Example {

	/**
	 * @throws Exception 
	 * @param args
	 * @throws  
	 */
	public static void main(String[] args) throws Exception  {
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.americangolf.co.uk/clothing-shoes/trousers");
		Actions act=new Actions(driver);
		/*this Action keyword is essential for 
		 * mouse movement related activities*/
		WebElement slider1=driver.findElement(By.xpath("//*[@id='secondary']/div/div[2]/div[1]/div[1]/span[1]"));
		//finding the xpath for the first slider button
	    act.dragAndDropBy(slider1, 50,0 ).build().perform(); //for movement from left to right
	    Thread.sleep(1000);
	    Actions act1=new Actions(driver);
	    WebElement slider2=driver.findElement(By.xpath("//*[@id='secondary']/div/div[2]/div[1]/div[1]/span[2]"));
	  //finding the xpath for the second slider button
	    act1.dragAndDropBy(slider2, -80,0 ).build().perform(); //for movement from right to left
	}

}
