package selenium;
// Here we will split the sentence based on some particular word or letter

public class String_Functional {

	
	public static void main(String[] args) {
		
		
		// object of string class is made
		String x= "hello how are you. Today is a good day.";
		//String c = new String("ssss sss");
		
		//System.out.println(x.charAt(10));
		//System.out.println(x.indexOf('a',11));
		//System.out.println(x.equals("hello how are you. Is is a good day."));
		//System.out.println(x.substring(10, 20));// end index -1
		//System.out.println(x.indexOf("XXXXXXX"));
		
String[] arr = x.split("o"); 
/*the above command will split the words, when the mentioned words appears,
 * Here i have written 'o', hence the above sentence will be splitted at those place where 'o' comes.
 * check the output*/
		
		for(int i=0 ; i< arr.length ; i++){
			System.out.println(arr[i]);
		}
		/*Output will be like this: Whereever 'o' letter comes, it will split the text
		 * hell
		 * h
		 * w are y
		 * u. T
		 * day is a g
		 * d day. */
		
		/*System.out.println("*********CONVERSION************");
		// conversion
		String y="986" ;
		int h=Integer.parseInt(y);
		int a=Integer.reverseBytes(h);
		System.out.println(h);
		System.out.println(a);
		
		String c=String.valueOf(h);
		System.out.println(c);*/
	}

	}



