package selenium;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;


public class Desired_Example {

	
	public static void main(String[] args) {
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setJavascriptEnabled(false);
		System.out.println(cap.isJavascriptEnabled());
		//cap.setCapability(CapabilityType.PROXY, value);
		
		
		FirefoxDriver driver = new FirefoxDriver(cap);
		
		//System.setProperty("webdriver.chrome.driver", "H:\\chromedriver.exe");
		//ChromeDriver d1 = new ChromeDriver(capailities);
		
		

	}

}
