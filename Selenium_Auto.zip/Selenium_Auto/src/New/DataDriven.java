package New;

import java.io.FileInputStream;

import org.apache.poi.hslf.model.Sheet;
import org.apache.poi.hssf.model.Workbook;


public class DataDriven {
	public void readExcel() throws BiffException, IOException{
			String FilePath = "D:\\sampledoc.xls";
			 FileInputStream fs = new FileInputStream(FilePath);
			 Workbook wb = Workbook.createWorkbook();
			 
			 //TO get the access to the sheet
			int sh = wb.getSheetIndex("Sheet2");
			
			// To get the number of rows present in sheet
			int rows = sh.getRows();
			
			// To get the number of columns present in sheet
			int cols = sh.getColumns();
					
			for(int row=0; row<sh.getRows(); row++)
			{
				System.out.print(sh.getCell(0,0).getContents());
				System.out.print(":::");
				System.out.println(sh.getCell(1,1).getContents());
			}
	}
	public static void main(String args[]) throws BiffException, IOException
	{
		DataDriven DT = new DataDriven();
		DT.readExcel();
	}
}