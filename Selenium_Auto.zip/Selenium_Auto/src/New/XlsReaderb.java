import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class XlsReaderb {

	
	public static void main(String[] args) throws IOException {
		FileInputStream file = new FileInputStream(new File("D:\\test.xls"));
		HSSFWorkbook workbook = new HSSFWorkbook(file);
		HSSFSheet sheet = workbook.createSheet("Sample");
		//Create a new row in current sheet
		Row row = sheet.createRow(2);
		//Create a new cell in current row
		Cell cell = row.createCell(2);
		//Set value to new value
		cell.setCellValue("Blahblah");
		

		
	}
}
