package WebDriverExample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class WebDriver_Code {

	
	public static void main(String[] args) throws Exception {
		HtmlUnitDriver driver=new HtmlUnitDriver();
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\chandkum\\Desktop\\chromedriver.exe");
		//System.setProperty("webdriver.ie.driver","C:\\Users\\chandkum\\Desktop\\IEDriverServer.exe");
		//WebDriver driver=new ChromeDriver();
		//WebDriver driver=new InternetExplorerDriver();
		driver.get("https://www.gmail.com");
		System.out.println(driver.getTitle());
		/*driver.findElement(By.xpath("//*[@id='Email']")).sendKeys("chandan.jha4");
		driver.findElement(By.xpath("//*[@id='next']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='Passwd']")).sendKeys("chandan");
		driver.findElement(By.xpath("//*[@id='signIn']")).click();*/
		//driver.findElement(By.id("Email")).sendKeys("chandan.jha4");
		//driver.findElement(By.className("need-help")).click();
		//driver.findElement(By.linkText("Create account")).click();
		//driver.findElement(By.partialLinkText("account")).click();
		//Thread.sleep(1000);
		//driver.findElement(By.id("Passwd")).sendKeys("chandan");
		//driver.findElement(By.id("signIn")).click();
		//Thread.sleep(1000);
		//driver.findElement(By.cssSelector("input[name^='Ema']")).sendKeys("startswith");
		//driver.findElement(By.cssSelector("input[name$='ail']")).sendKeys("endswith");
		//driver.findElement(By.cssSelector("a[class*='-hel']")).click();
		// el=driver.findElements(By.tagName("a"));
		//driver.findElement(By.cssSelector("css=a:contains('Create account')")).click();

	}
	}


