
package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;


public class Seleniumweb2 
{
	@Test
	public void verifytitle()
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///E:/selenioum/new.html");
		String exptitle="Title of the document";
		String actualtitle=driver.getTitle();
		System.out.println("expected title =" + exptitle);
		System.out.println("Actual title =" + actualtitle);
			
		if(exptitle.equalsIgnoreCase(actualtitle))
		{
			System.out.println("applicaiton launched");
		}
		else
		{
			System.out.println("fail to launch");
		}
		//exit browser
	driver.quit();
		
	}
}
