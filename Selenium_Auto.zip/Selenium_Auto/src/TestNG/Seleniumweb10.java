
package TestNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Seleniumweb10 
{
	@Test
	public void ChromebrowserLogin() throws Throwable
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\MUSBAH15\\Desktop\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to("http://192.168.1.71:81/common_project/dar_manager/dar_manager/index.php/login");
		/*String exptext="Please identify yourself";
		String actualtext=driver.findElement(By.id("headerContainer")).getText();
		if(exptext.equalsIgnoreCase(actualtext))
		{
			System.out.println("applicaiton loaded");
		}
		else
		{
			System.out.println("applicaiton fail to load");
		}
		driver.findElement(By.id("username")).sendKeys("admin");
		driver.findElement(By.name("pwd")).sendKeys("manager");
		driver.findElement(By.id("keepLoggedInCheckBoxContainer")).click();
		driver.findElement(By.id("loginButton")).click();
		Thread.sleep(2000);
		String expurl="http://localhost:8080/user/submit_tt.do";
		String acturl=driver.getCurrentUrl();
		System.out.println(acturl);
		if(expurl.equalsIgnoreCase(acturl))
		{
			System.out.println("login successful");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//table[@id='topnav']/tbody/tr[1]/td[5]/a/img")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@class='navBg']/table[1]/tbody/tr[1]/td[7]/a/img")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@class='navBg']/table[1]/tbody/tr[1]/td[9]/a/img")).click();
		}
		else
		{
			System.out.println("fail to login");
		}
		Thread.sleep(2000);
		driver.findElement(By.id("logoutLink")).click();
		Thread.sleep(2000);
		driver.quit();
		*/
}
}
