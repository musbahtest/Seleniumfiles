
package TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Seleniumweb3 
{
	public static void main(String[] args) throws Exception {
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///E:/selenioum/new.html");
		boolean beforeclickstatus =driver.findElement(By.xpath("//input[@value='male']")).isSelected();
		System.out.println("before click " + beforeclickstatus);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@value='male']")).click();
		boolean afterclickstatus =driver.findElement(By.xpath("//input[@value='male']")).isSelected();
		System.out.println("afterclick  " + afterclickstatus);
		driver.findElement(By.xpath("//input[@value='female']")).click();
		driver.findElement(By.xpath("//input[@value='male']")).click();
		driver.findElement(By.xpath("//input[@value='female']")).click();
		driver.findElement(By.xpath("//input[@value='male']")).click();
		
		driver.quit();
}
}
