package TestNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Seleniumweb6 
{
	@Test
	public void Login() throws Throwable
	{
		WebDriver driver = new FirefoxDriver();
		//maximize window
		driver.manage().window().maximize();
		//syunc
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//pass url
		driver.navigate().to("http://localhost:8080/login.do");
		String exptext="Please identify yourself";
		String actualtext=driver.findElement(By.id("headerContainer")).getText();
		if(exptext.equalsIgnoreCase(actualtext))
		{
			System.out.println("applicaiton loaded");
		}
		else
		{
			System.out.println("applicaiton fail to load");
		}
		driver.findElement(By.id("username")).sendKeys("admin");
		driver.findElement(By.name("pwd")).sendKeys("manager");
		driver.findElement(By.id("keepLoggedInCheckBoxContainer")).click();
		driver.findElement(By.id("loginButton")).click();
		String expurl="http://localhost:8080/user/submit_tt.do";
		String acturl=driver.getCurrentUrl();
		if(expurl.equalsIgnoreCase(acturl))
		{
			System.out.println("login successful");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//table[@id='topnav']/tbody/tr[1]/td[5]/a/img")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@class='navBg']/table[1]/tbody/tr[1]/td[7]/a/img")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@class='navBg']/table[1]/tbody/tr[1]/td[9]/a/img")).click();
		}
		else
		{
			System.out.println("fail to login");
		}
		driver.findElement(By.id("logoutLink")).click();
		Thread.sleep(2000);
		driver.quit();
		
}
}
