
package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Seleniumweb1 
{
	@Test
	public void launchbrowser()
	{
		//opening firefox browser
		WebDriver driver = new FirefoxDriver();
		//passing url to browser
		try{
		//driver.get("file:///E:testNG/Dar.html"); 
		driver.get("file:///C:/Users/MUSBAH15/Desktop/testing urls.txt");
		//to open a file from the drive with 3 slash "///",then Drive name, then colon, then folder name, file name
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
