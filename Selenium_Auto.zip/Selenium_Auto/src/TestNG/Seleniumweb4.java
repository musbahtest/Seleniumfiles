package TestNG;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Seleniumweb4 
{
	@Test
	public void Singleselectcombobox() throws Throwable
	{
		WebDriver driver = new FirefoxDriver();
		//maximize window
		driver.manage().window().maximize();
		driver.get("file:///E:/selenioum/new.html");
		WebElement combob= driver.findElement(By.name("selectionField"));
		//System.out.println(combob);
		Select s = new Select(combob);
		s.selectByIndex(3);
		Thread.sleep(2000);
		s.selectByValue("pu");
		Thread.sleep(2000);
		s.selectByVisibleText("Bangalore");
		Thread.sleep(2000);
		List<WebElement> list1= s.getOptions();
		for(int i=0;i<list1.size();i++)
		{
			System.out.println(list1.get(i).getText());
		}
		
		driver.quit();
}
}
