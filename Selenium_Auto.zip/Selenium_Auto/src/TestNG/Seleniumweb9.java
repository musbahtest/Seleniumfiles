package TestNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Seleniumweb9 
{
	@Test
	public void verifytooltip() throws Exception 
	
	{
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.navigate().to("http://localhost:8080/login.do");
		Thread.sleep(2000);
		Actions act=new Actions(driver);
		WebElement ele= driver.findElement(By.xpath("//*[@id='keepLoggedInLabel']"));
		act.moveToElement(ele).build().perform();
		String expectedval="D not select if this computer is shared";
	
		String actual=driver.findElement(By.id("keepMeLoggedInCaptionContainer")).getAttribute("title");
		
		Assert.assertEquals(actual,expectedval, "text not matched");
		
		
		
		//Assert.a
	
		System.out.println("tooltip is " + actual);
		//driver.quit();
}
	
	@Test
	public void m1()
	{
		System.out.println("ALL TC EXECUTED ");
	}
}
