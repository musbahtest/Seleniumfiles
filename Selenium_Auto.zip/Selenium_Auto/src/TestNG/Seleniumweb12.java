
package TestNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Seleniumweb12 
{
	@Test
	public void Hiddendivisionpopup() throws Throwable
	{
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to("http://localhost:8080/login.do");
		driver.findElement(By.id("username")).sendKeys("admin");
		driver.findElement(By.name("pwd")).sendKeys("manager");
		driver.findElement(By.id("keepLoggedInCheckBoxContainer")).click();
		driver.findElement(By.id("loginButton")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//table[@id='topnav']/tbody/tr[1]/td[5]/a/img")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='navBg']/table[1]/tbody/tr[1]/td[7]/a/img")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='navBg']/table[1]/tbody/tr[1]/td[9]/a/img")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("profile-link")).click();
		driver.findElement(By.name("firstName")).clear();
		driver.findElement(By.name("firstName")).sendKeys("sdfdsf");
		driver.findElement(By.name("lastName")).clear();
		driver.findElement(By.name("lastName")).sendKeys("Sdfdsf");
		Thread.sleep(2000);
		driver.findElement(By.id("logoutLink")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("RemainOnThePageButton")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("logoutLink")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("DiscardChangesButton")).click();
		Thread.sleep(2000);
		driver.quit();
}
}