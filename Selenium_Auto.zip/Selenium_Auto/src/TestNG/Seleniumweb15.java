package TestNG;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Seleniumweb15 
{
	@Test
	public void findelements() throws Throwable
	{
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to("http://fanosy.com");
		driver.findElement(By.id("username")).sendKeys("admin");
		driver.findElement(By.name("pwd")).sendKeys("manager");
		driver.findElement(By.id("keepLoggedInCheckBoxContainer")).click();
		driver.findElement(By.id("loginButton")).click();
		
		List<WebElement> list1 =driver.findElements(By.tagName("a"));
		for(int i=0; i<list1.size();i++)
		{
			String url =list1.get(i).getAttribute("href");
			System.out.println(url);
		}
		driver.quit();
		
		
}
}