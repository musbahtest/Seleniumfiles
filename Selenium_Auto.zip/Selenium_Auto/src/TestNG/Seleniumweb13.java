
package TestNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Seleniumweb13 
{
	@Test
	public void Hiddendivisionpopup() throws Throwable
	{
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
	//	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to("https://www.gmail.com");
		driver.findElement(By.id("Email")).sendKeys("manjurock.n");
		driver.findElement(By.id("next")).click();
		driver.findElement(By.id("Passwd")).sendKeys("dsfsdf");
		driver.findElement(By.id("signIn")).click();
		driver.navigate().refresh();
		Thread.sleep(2000);
		// yes case
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		// no case
		driver.switchTo().alert().dismiss();
		Thread.sleep(2000);
		driver.quit();
}
}
