package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Gmail_TestNG {

	 WebDriver driver=null;
		@BeforeTest
		public void openConnection(){
			// db connection
			System.out.println("connected to database");
		}

		@AfterTest
		public void closeConnection(){
			System.out.println("closing the database connection");
		}

		@BeforeMethod
		public void openBrowser(){
			// selenium
			 driver=new FirefoxDriver();
			 driver.get("https://www.gmail.com");
			System.out.println("Opening browser");
		}

		@AfterMethod
		public void closeBrowser(){
			System.out.println("Closing browser");
			driver.close();

		}

		@Test // annotation - represents test case
		public void testLogin(){
			// selenium code
			//driver.get("http://www.gmail.com");
			System.out.println("Executing logintest");
		}



		@Test
		public void testRegister(){
			System.out.println("Testing the registration");
		}


}
