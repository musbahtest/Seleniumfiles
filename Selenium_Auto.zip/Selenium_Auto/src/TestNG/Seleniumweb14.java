package TestNG;



import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;

public class Seleniumweb14 
{
	String choice;
	WebDriver driver;
	 Scanner in = new Scanner(System.in);
	@Test
	public void SSL() throws Throwable
	{
		 System.out.println("choices: \n ff \n ch");
	      System.out.println("Enter a choice:");
	      choice = in.nextLine();
	      System.out.println("Your entered choice is: "+choice);
	switch(choice)
	{
	case "ff":
		WebDriver driver = new FirefoxDriver();
		 driver.navigate().to("http://www.google.com");
		break;
	case "ch":
		System.setProperty("webdriver.chrome.driver", "E:\\SEleniumWebworkspace\\chromedriver.exe");
		 driver=new ChromeDriver(); 
		 driver.navigate().to("http://www.google.com");
		break;
	case "ie":
		System.setProperty("webdriver.ie.driver", "E:\\SEleniumWebworkspace\\IEDriverServer.exe");
		 driver=new InternetExplorerDriver(); 
		 driver.navigate().to("http://www.google.com");
		 driver.navigate().to("javascript:document.getElementById('overridelink').click()");
		break;
	 default :
		System.out.println("Invalid Choice"); 
		System.exit(0);
		break;
		
	}
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
}
}