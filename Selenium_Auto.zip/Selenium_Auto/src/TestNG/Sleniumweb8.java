package TestNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Sleniumweb8 
{
	@Test
	public void browseraction() throws Throwable
	{
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to("http://www.seleniumhq.org/");
		driver.findElement(By.linkText("Projects")).click();
		driver.findElement(By.linkText("Download")).click();
		driver.findElement(By.linkText("Documentation")).click();
		driver.findElement(By.linkText("Support")).click();
		
		driver.navigate().back();
		Thread.sleep(2000);
		driver.navigate().forward();
		Thread.sleep(2000);
		driver.navigate().refresh();
		driver.quit();
		
}
}

